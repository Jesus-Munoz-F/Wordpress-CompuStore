Ejecutar con:

docker-compose up -d
